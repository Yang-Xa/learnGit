#include <iostream>
#include <fstream>
#include <cstdio>
#include <string>
#include <vector>
#include <list>
#include <queue>

#include "common.hpp"
#include "lognum.hpp"
#include "data.hpp"
#include "stacksubset.hpp"
#include "scores.hpp"
#include "bestdagdp.hpp"


using std::list;
using std::queue;
using std::vector;

using namespace std;

void findPartialOrder(Data &data, list<int> &targets, list<int> &order)
{
	double equivalentSampleSize = 1;
	int localMaxIndegree = 5;
	int nVariables = data.nVariables;
	ScoreFun *scoreFun = new BDeuScore(equivalentSampleSize);
	DataColumns dataColumns(data, vector<int>(targets.begin(), targets.end()));
	findBestDAG(dataColumns, localMaxIndegree, scoreFun, order);
}
