#include <iostream>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <string>
#include <vector>
#include <list>
#include <queue>

#include "common.hpp"
#include "lognum.hpp"
#include "logger.hpp"
#include "timer.hpp"
#include "data.hpp"
#include "stacksubset.hpp"
#include "scores.hpp"
#include "bestdagdp.hpp"
#include "order.hpp"

using std::list;
using std::vector;
using namespace std;
int main(int argc,char** argv)
{
    if(argc<=1){
        cerr<<"usage: ./main inputfile"<<endl;
        return -1;
    }
    Data data;
    istream inStream(0);
    ifstream inFile;
    inFile.open(argv[1]);
    inStream.rdbuf(inFile.rdbuf());
    data.read(inStream);
    if(inFile.is_open())
        inFile.close();
    int nVariables = data.nVariables;
    list<int> targets;
    for(int i=0;i<nVariables;++i)
    {
        targets.push_back(i);
    }
    list<int> orders;
    findPartialOrder(data,targets,orders);
    list<int>::iterator oit;
    for(oit=orders.begin();oit!=orders.end();++oit)
    {
        cout<<(*oit)<<" ";
    }
    cout<<endl;
    return 0;
}